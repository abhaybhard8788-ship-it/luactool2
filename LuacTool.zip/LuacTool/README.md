1. unluac.jar download karke `app/libs/unluac.jar` mein rakho (https://sourceforge.net/projects/unluac/).
2. Repo GitHub pe push karo -> Actions tab -> Build APK -> Artifacts se APK download.
